#!/usr/bin/env python3
def print_greeting():
    print("Welcome to the Brain Games!")

def main():
    print_greeting()

if __name__ == "__main__":
    main()

