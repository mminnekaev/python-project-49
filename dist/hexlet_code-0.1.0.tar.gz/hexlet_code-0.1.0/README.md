### Hexlet tests and linter status:
[![Actions Status](https://github.com/mminnekaev/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/mminnekaev/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/c8859dd8e69bbdb03b49/maintainability)](https://codeclimate.com/github/mminnekaev/python-project-49/maintainability)

### Install and play example
https://asciinema.org/a/BS4We7INNB5QJEFrCBYX9nb0v