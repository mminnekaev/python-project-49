import brain_games

def main():
    brain_games.print_greeting()

if __name__ == "__main__":
    main()
